package com.jdi.word;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.jdi.util.Action;

public class WordAutoCompleteService implements Action {

    @Override
    public void process(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String key = request.getParameter("key");

        System.out.println("[AUTO] key = " + key);  // ★ 1) 검색어 출력

        WordDAO dao = WordDAO.getInstance();
        List<WordDTO> list = dao.autoComplete(key);

        System.out.println("[AUTO] DAO 결과: " + list);  // ★ 2) DB 결과 출력

        Gson gson = new Gson();
        String json = gson.toJson(list);

        response.setContentType("application/json; charset=UTF-8");
        response.getWriter().write(json);
    }
}
