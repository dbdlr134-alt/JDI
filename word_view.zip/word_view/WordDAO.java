package com.jdi.word;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.jdi.util.DBM;

public class WordDAO {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	private WordDAO() {}
	private static WordDAO instance = new WordDAO();
	public static WordDAO getInstance() {
		return instance;
	}
	
	//word_id로 검색
	public WordDTO wordSelect(int word_id){
		WordDTO dto = new WordDTO();
		String sql="SELECT * FROM japanese_word WHERE word_id = ?";
		try {
			conn=DBM.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, word_id);
			
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				dto.setWord_id(rs.getInt("word_id"));
				dto.setWord(rs.getString("word"));
				dto.setDoc(rs.getString("doc"));
				dto.setKorean(rs.getString("korean"));
				dto.setJlpt(rs.getString("jlpt"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBM.close(conn, pstmt, rs);
		}
		return dto;
	}
	//검색
	public List<WordDTO> WordSearch(String key){
		List<WordDTO> list = new ArrayList();
		String sql = "SELECT * FROM JAPANESE_WORD "
				+ "WHERE word LIKE ? "
				+ "OR doc LIKE ? "
				+ "OR korean LIKE ? "
				+ "ORDER BY word_id DESC";
		
		try {
			conn=DBM.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, "%"+key+"%");
			pstmt.setString(2, "%"+key+"%");
			pstmt.setString(3, "%"+key+"%");
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				WordDTO dto = new WordDTO();
				dto.setWord_id(rs.getInt("word_id"));
				dto.setWord(rs.getString("word"));
				dto.setDoc(rs.getString("doc"));
				dto.setKorean(rs.getString("korean"));
				dto.setJlpt(rs.getString("jlpt"));
				
				list.add(dto);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBM.close(conn, pstmt, rs);
		}
		return list;
	}
	
	//검색시 자동완성
	public List<WordDTO> autoComplete(String key){
		List<WordDTO> list = new ArrayList();
		String sql="SELECT word, doc, korean "
				+ "FROM JAPANESE_WORD "
				+ "WHERE word LIKE CONCAT(?, '%') "
				+ "OR doc LIKE CONCAT(?, '%') "
				+ "OR korean LIKE CONCAT(?, '%') "
				+ "LIMIT 10";
		
		try {
			conn=DBM.getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, key);
			pstmt.setString(2, key);
			pstmt.setString(3, key);
			
			rs=pstmt.executeQuery();
			while(rs.next()) {
				WordDTO dto = new WordDTO();
				dto.setWord_id(rs.getInt("word_id"));
				dto.setWord(rs.getString("word"));
				dto.setDoc(rs.getString("doc"));
				dto.setKorean(rs.getString("korean"));
				dto.setJlpt(rs.getString("jlpt"));
				
				list.add(dto);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			DBM.close(conn, pstmt,rs);
		}
		return list;
	}
	
	//검색 메소드
		// ★ 고급 검색 메소드 (정확도 우선 정렬 + 뜻 검색 포함) ★
	    public ArrayList<WordDTO> searchWords(String keyword) {
	        ArrayList<WordDTO> list = new ArrayList<>();
	        String sql = "SELECT * FROM japanese_word "
	                   + "WHERE word LIKE ? OR korean LIKE ? "
	                   + "ORDER BY (CASE WHEN word = ? THEN 0 ELSE 1 END), LENGTH(word)";
	        
	        try {
	            conn = DBM.getConnection();
	            pstmt = conn.prepareStatement(sql);
	            
	            // 1. 첫 번째 ? : 단어 포함 검색 (%검색어%)
	            pstmt.setString(1, "%" + keyword + "%");
	            // 2. 두 번째 ? : 뜻(한국어) 포함 검색 (%검색어%)
	            pstmt.setString(2, "%" + keyword + "%");
	            // 3. 세 번째 ? : 정렬을 위한 '정확한 단어' (순수 검색어)
	            pstmt.setString(3, keyword);
	            
	            rs = pstmt.executeQuery();
	            
	            while(rs.next()) {
	                WordDTO dto = new WordDTO();
	                dto.setWord_id(rs.getInt("word_id"));
	                dto.setWord(rs.getString("word"));      // 한자
	                dto.setDoc(rs.getString("doc"));        // 음독 (컬럼명 doc)
	                dto.setKorean(rs.getString("korean"));  // 뜻 (컬럼명 korean)
	                dto.setJlpt(rs.getString("jlpt"));      // 급수
	                
	                list.add(dto);
	            }
	        } catch(Exception e) {
	            e.printStackTrace();
	        } finally {
	            DBM.close(conn, pstmt, rs); // DBM에 3개짜리 close 메소드가 있다고 가정
	        }
	        
	        return list;
	    }
	    
	 
	
}