package com.mjdi.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mjdi.util.Action;

public class QnAViewService implements Action {

    @Override
    public void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        // 1. 어떤 질문을 볼 건지 ID(파라미터) 받기
        String qIdStr = request.getParameter("q_id");
        
        // ID가 없으면 목록으로 쫓아냄
        if (qIdStr == null || qIdStr.equals("")) {
            response.sendRedirect("QnAController?cmd=qna_list");
            return;
        }

        int qId = Integer.parseInt(qIdStr);
        
        // 2. DAO 호출
        QuestionDAO dao = QuestionDAO.getInstance();
        
        // (1) 질문 상세 정보 가져오기 (조회수 증가 포함됨)
        QuestionDTO qDto = dao.getQuestion(qId);
        
        // (2) 해당 질문에 달린 답변 리스트 가져오기
        List<QuestionDTO> aList = dao.getAnswerList(qId);
        
        // 3. 질문이 삭제되었거나 없는 경우 처리
        if (qDto == null) {
            response.setContentType("text/html; charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<script>");
            out.println("alert('존제하지않는 글 입니단.');");
            out.println("location.href='QnAController?cmd=qna_list';");
            out.println("</script>");
            out.close();
            return;
        }

        // 4. JSP로 보낼 데이터 짐 싸기 (request.setAttribute)
        request.setAttribute("q", qDto);       // 질문 내용
        request.setAttribute("aList", aList);  // 답변 목록
        
        // [중요] JSP의 fn:replace에서 사용할 줄바꿈 문자(\n)를 보냄
        request.setAttribute("newLine", "\n"); 

        // 5. 화면 이동 (qna_view.jsp)
        String path = "/qna_view.jsp"; 
        RequestDispatcher dispatcher = request.getRequestDispatcher(path);
        dispatcher.forward(request, response);
    }
}