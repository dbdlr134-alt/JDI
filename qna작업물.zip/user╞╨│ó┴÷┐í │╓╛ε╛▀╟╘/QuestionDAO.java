package com.mjdi.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mjdi.util.DBM;
// QuestionDTO import가 필요하다면 추가해 (같은 패키지면 생략 가능)

public class QuestionDAO {
    // 싱글톤 패턴
    private static QuestionDAO instance = new QuestionDAO();
    public static QuestionDAO getInstance() { return instance; }
    private QuestionDAO() {}
    
    
    // ==========================================
    // 1. 질문(Question) 관련 기능
    // ==========================================

    // [질문 등록]
    public int insertQuestion(QuestionDTO dto) {
        int result = 0;
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        // 테이블 구조에 맞춰서 (status 없음)
        String sql = "INSERT INTO jdi_questions (writer_user, title, content) VALUES (?, ?, ?)";
        
        try {
            conn = DBM.getConnection();
            pstmt = conn.prepareStatement(sql);
            
            pstmt.setString(1, dto.getWriter_user());
            pstmt.setString(2, dto.getTitle());
            pstmt.setString(3, dto.getContent());
            
            result = pstmt.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("으헤~ 질문 등록하다 에러 났어: " + e.getMessage());
        } finally {
            DBM.close(conn, pstmt);
        }
        return result;
    }

    // [질문 목록]
    public List<QuestionDTO> getQuestionList() {
        List<QuestionDTO> list = new ArrayList<>();
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String sql = "SELECT q.q_id, q.writer_user, q.title, q.view_count, "
                   + "DATE_FORMAT(q.created_at, '%Y-%m-%d') AS created_at, "
                   + "(SELECT COUNT(*) FROM jdi_answers a WHERE a.q_id = q.q_id) AS answer_count "
                   + "FROM jdi_questions q ORDER BY q.q_id DESC";
        
        try {
            conn = DBM.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                QuestionDTO dto = new QuestionDTO();
                dto.setQ_id(rs.getInt("q_id"));
                dto.setWriter_user(rs.getString("writer_user"));
                dto.setTitle(rs.getString("title"));
                dto.setView_count(rs.getInt("view_count"));
                dto.setCreated_at(rs.getString("created_at"));
                
                // [추가] 조회한 답변 개수를 DTO에 담기
                dto.setAnswer_count(rs.getInt("answer_count"));
                
                list.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBM.close(conn, pstmt, rs);
        }
        return list;
    }
    // [질문 상세]
    public QuestionDTO getQuestion(int qId) {
        QuestionDTO dto = null;
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        String sqlHit = "UPDATE jdi_questions SET view_count = view_count + 1 WHERE q_id = ?";
        
        // [수정] status 컬럼 제거함
        String sqlSelect = "SELECT q_id, writer_user, title, content, view_count, "
                         + "DATE_FORMAT(created_at, '%Y-%m-%d %H:%i') AS created_at " 
                         + "FROM jdi_questions WHERE q_id = ?";
        
        try {
            conn = DBM.getConnection();
            
            // 1. 조회수 증가
            pstmt = conn.prepareStatement(sqlHit);
            pstmt.setInt(1, qId);
            pstmt.executeUpdate();
            pstmt.close(); 
            
            // 2. 상세 내용 조회
            pstmt = conn.prepareStatement(sqlSelect); 
            pstmt.setInt(1, qId);
            rs = pstmt.executeQuery();
            
            if (rs.next()) {
                dto = new QuestionDTO();
                dto.setQ_id(rs.getInt("q_id"));
                dto.setWriter_user(rs.getString("writer_user"));
                dto.setTitle(rs.getString("title"));
                dto.setContent(rs.getString("content")); 
                dto.setView_count(rs.getInt("view_count"));
                dto.setCreated_at(rs.getString("created_at"));
                
                // dto.setStatus(...) -> 여기도 삭제!
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBM.close(conn, pstmt, rs);
        }
        return dto;
    }
    
    // [질문 삭제]
    public int deleteQuestion(int qId) {
        int result = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        String sql = "DELETE FROM jdi_questions WHERE q_id = ?";
        
        try {
            conn = DBM.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, qId);
            result = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBM.close(conn, pstmt);
        }
        return result;
    }

    // ==========================================
    // 2. 답변(Answer) 관련 기능
    // ==========================================

    // [답변 등록]
    public int insertAnswer(QuestionDTO dto) {
        int result = 0;
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        String sql = "INSERT INTO jdi_answers (q_id, writer_user, content) VALUES (?, ?, ?)";
        
        try {
            conn = DBM.getConnection();
            pstmt = conn.prepareStatement(sql);
            
            pstmt.setInt(1, dto.getQ_id());
            pstmt.setString(2, dto.getWriter_user());
            pstmt.setString(3, dto.getContent());
            
            result = pstmt.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBM.close(conn, pstmt);
        }
        return result;
    }

    // [답변 목록]
    public List<QuestionDTO> getAnswerList(int qId) {
        List<QuestionDTO> list = new ArrayList<>();
        
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        // [수정] is_accepted 컬럼 제거함 (DB 테이블에 없음!)
        String sql = "SELECT a_id, q_id, writer_user, content, "
                   + "DATE_FORMAT(created_at, '%Y-%m-%d %H:%i') AS created_at "
                   + "FROM jdi_answers WHERE q_id = ? ORDER BY a_id ASC";
        
        try {
            conn = DBM.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, qId);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                QuestionDTO dto = new QuestionDTO();
                dto.setA_id(rs.getInt("a_id"));
                dto.setQ_id(rs.getInt("q_id"));
                dto.setWriter_user(rs.getString("writer_user"));
                dto.setContent(rs.getString("content"));
                dto.setCreated_at(rs.getString("created_at"));
                
                // dto.setIs_accepted(...) -> 삭제! 테이블에 컬럼이 없음.
                
                list.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBM.close(conn, pstmt, rs);
        }
        return list;
    }
}