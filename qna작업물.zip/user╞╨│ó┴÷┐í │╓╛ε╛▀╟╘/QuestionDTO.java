package com.mjdi.user;

public class QuestionDTO {
	private int q_id;
	private int a_id;
    private String writer_user;
    private String title;
    private String content;
    private int view_count;
    private String status;
    private String created_at; 
    private String updated_at;
    private String is_accepted;
    private int answer_count;
    
	public int getAnswer_count() {
		return answer_count;
	}
	public void setAnswer_count(int answer_count) {
		this.answer_count = answer_count;
	}
	public String getIs_accepted() {
		return is_accepted;
	}
	public void setIs_accepted(String is_accepted) {
		this.is_accepted = is_accepted;
	}
	public int getA_id() {
		return a_id;
	}
	public void setA_id(int a_id) {
		this.a_id = a_id;
	}
	public int getQ_id() {
		return q_id;
	}
	public void setQ_id(int q_id) {
		this.q_id = q_id;
	}
	public String getWriter_user() {
		return writer_user;
	}
	public void setWriter_user(String writer_user) {
		this.writer_user = writer_user;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getView_count() {
		return view_count;
	}
	public void setView_count(int view_count) {
		this.view_count = view_count;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(String updated_at) {
		this.updated_at = updated_at;
	}
    
}
